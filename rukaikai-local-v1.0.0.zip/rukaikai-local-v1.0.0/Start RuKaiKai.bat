@echo off
setlocal
cd /d "%~dp0"

echo RuKaiKai Local
echo ===============

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 22.13 or newer is required.
  start "" "https://nodejs.org/en/download"
  pause
  exit /b 1
)

node -e "const [major, minor] = process.versions.node.split('.').map(Number); process.exit(major > 22 || (major === 22 && minor >= 13) ? 0 : 1)"
if errorlevel 1 (
  echo Node.js 22.13 or newer is required. Your version is:
  node --version
  start "" "https://nodejs.org/en/download"
  pause
  exit /b 1
)

if exist .env.local (
  echo Using the custom provider and model settings in .env.local.
  echo Make sure that local model provider is already running.
) else (
  where ollama >nul 2>nul
  if errorlevel 1 (
    echo Ollama is required.
    start "" "https://ollama.com/download"
    pause
    exit /b 1
  )

  echo Checking the recommended local model...
  ollama show qwen3:4b-instruct >nul 2>nul
  if errorlevel 1 (
    echo Downloading Qwen 3 4B Instruct. This is about 2.5 GB and happens once.
    ollama pull qwen3:4b-instruct
    if errorlevel 1 (
      echo Open Ollama, then run this launcher again.
      pause
      exit /b 1
    )
  )
)

if not exist node_modules\.package-lock.json (
  echo Installing RuKaiKai packages. This happens on the first start.
  call npm install --no-audit --no-fund
  if errorlevel 1 (
    pause
    exit /b 1
  )
)

set RUKAIKAI_MODE=local

start "" powershell -NoProfile -WindowStyle Hidden -Command "$ProgressPreference='SilentlyContinue'; for($i=0; $i -lt 45; $i++){ try { Invoke-WebRequest -UseBasicParsing 'http://127.0.0.1:5173/api/health' | Out-Null; Start-Process 'http://127.0.0.1:5173'; break } catch {}; Start-Sleep -Seconds 1 }"
echo Starting RuKaiKai. Keep this window open; press Ctrl+C to stop.
call npm run dev
pause
