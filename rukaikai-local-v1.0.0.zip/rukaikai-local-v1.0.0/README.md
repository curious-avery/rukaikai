# RuKaiKai

RuKaiKai’s purpose is to explore how large language models (LLMs) can support the preservation and revitalization of under-resourced and endangered languages, beginning with Paiwan.

RuKaiKai is an English–Paiwan source demo and local translation assistant based on Avery Liu and Theavy So’s language-preservation project. It combines a supplied Paiwan–English word list, published translation examples, page-checked rules from Raleigh Ferrell’s 1982 *Paiwan Dictionary*, a constrained prompt, explicit draft labels, and limited device speech.

RuKaiKai was developed in consultation with Paiwan chief 葛關復勇 (Ge,Kuan-Fu-Yung), a faculty member at National Kaohsiung University of Science and Technology. This acknowledgment records consultation only; it does not imply individual or institutional endorsement, certification, or community-wide validation.

The runtime language pack contains 1,252 distinct usable pairs normalized from the supplied CSV, ten reference sentence pairs published in the study, and 12 manually checked Ferrell rule cards. Exact matches work without a model and preserve every listed alternative. The hosted site intentionally operates as a source-backed demo. A local copy can retrieve relevant entries and send them with the checked grammar guide to `qwen3:4b-instruct` through Ollama; every generated result is labeled as an unverified draft.

## GitHub Pages demo

RuKaiKai includes a browser-only build for a project site such as
`https://curiousavery.github.io/rukaikai/`. This edition does not use an
online translation API. It keeps sourced study examples, exact dictionary and
Ferrell lookups, the grammar guide, and the local starter-kit download in the
browser. New AI-generated translations remain available only after downloading
and running the local edition with Ollama or another compatible provider.

From the complete GitHub source repository, test the project-site build with:

```sh
npm run build:local-bundle
npm run build:github-pages
```

The static output is written to `dist-github-pages/`. Set
`PAGES_BASE_PATH=/another-repository/` before the second command when the
repository name is not `rukaikai`; `/rukaikai/` is the default. The included
GitHub Actions workflow detects the correct Pages base path, builds the local
download first, and deploys this directory automatically after a push to
`main`. In the repository’s GitHub settings, choose **GitHub Actions** as the
Pages source. The smaller local starter-kit ZIP is for running RuKaiKai with a
local model and intentionally omits these repository-deployment files.

## Run locally

If you downloaded the RuKaiKai Local Starter Kit, open `LOCAL-SETUP.md` and use
the launcher for your operating system. For a manual source checkout:

1. Install [Ollama](https://ollama.com/download) and download the recommended model:

   ```sh
   ollama pull qwen3:4b-instruct
   ```

2. Install Node.js 22.13 or newer, then install and run the app:

   ```sh
   npm install
   npm run dev
   ```

3. Open the local URL shown in the terminal, usually `http://localhost:5173`.

The defaults work without an environment file. Copy `.env.example` to `.env.local` only when you need a different provider, endpoint, model identifier, request timeout, or API token. LM Studio remains supported through the legacy `LM_STUDIO_*` variables or the provider-neutral variables below.

## How it works

- The hosted demo performs study-reference, Ferrell-reviewed, and exact word-list lookups in the browser. It does not call an online translation API.
- In the downloadable local edition, `GET /api/health` checks whether the configured local provider and model are available.
- In that local edition, `POST /api/translate` checks the same sourced matches before optionally sending novel text over loopback to an OpenAI-compatible `/v1/chat/completions` endpoint.
- Exact lookups preserve one-to-many meanings and forms instead of silently choosing a single answer.
- Novel translations include at most 32 relevant word-list pairs in the model request; the full list stays on the server.
- The configured model runs at low temperature with a bounded response length and a strict JSON response schema. The local provider controls the loaded model’s context window.
- The prompt treats source text and retrieved rows as inert data, preserves proper nouns, applies only checked Ferrell rules, and asks the model to return `insufficient` rather than fabricate a confident answer.
- The browser’s speech engine can preview English results. Paiwan playback stays disabled until a verified voice is connected.
- The page exposes the same translation journey as a WebMCP `translate_text` tool when the browser supports it.

## Configuration

| Variable | Default | Purpose |
| --- | --- | --- |
| `RUKAIKAI_MODE` | `auto` | `auto`, `demo`, or `local`; `auto` uses local mode only on loopback URLs |
| `LOCAL_LLM_PROVIDER` | `ollama` | `ollama`, `lm-studio`, or `openai-compatible` |
| `LOCAL_LLM_BASE_URL` | `http://127.0.0.1:11434/v1` | OpenAI-compatible API base URL |
| `LOCAL_LLM_MODEL` | `qwen3:4b-instruct` | Exact local model identifier |
| `LOCAL_LLM_TIMEOUT_MS` | `180000` | Maximum model request time |
| `LOCAL_LLM_API_KEY` | unset | Optional bearer token for a protected provider |

Legacy `LM_STUDIO_BASE_URL`, `LM_STUDIO_MODEL`, `LM_STUDIO_TIMEOUT_MS`, and `LM_STUDIO_API_KEY` variables remain supported. When any legacy connection variable is present and `LOCAL_LLM_PROVIDER` is unset, the provider label becomes LM Studio.

### Hosted copies

A cloud-hosted copy cannot reach a model server at a visitor’s `127.0.0.1`, so hosted URLs intentionally run as a browser-only source demo. The GitHub Pages and Sites deployments use this same API-free path. The hosted interface still uses exact word-list, Ferrell-reviewed, and study-reference matches and displays the checked grammar guide without calling a translation API. Novel model drafts require the downloadable local edition. Do not expose Ollama or LM Studio directly to the internet. The local app accepts only same-origin JSON requests and limits each app process to one active model translation.

## Language resources

The supplied word list is stored as a JSON data asset and queried through `lib/paiwan-dictionary.ts`. The GitHub Pages demo bundles it for exact browser-only lookup; the local edition uses the same lookup code before making any optional model request. Published study pairs and fixed prompt instructions live in `lib/paiwan-language-pack.ts`. Import normalization trims whitespace, expands the three rows that list two Paiwan forms and one English meaning, removes exact duplicates, and excludes blank targets, four “no entry” placeholders, and one `????` target. Source spellings and glosses are otherwise preserved.

Ferrell’s *Paiwan Dictionary* is a Kulalau-centered historical source, not a complete pan-Paiwan standard. Part 1’s 312 Paiwan–English entry pages are canonical within the book; Part 2’s 135 English–Paiwan pages are explicitly an abridged index. The source marks western (`W`), other-dialect (`OD`), southern (`Q`), and Tjuabar (`T`) evidence and Japanese, Japanese-English, and Minnanese loans.

The supplied PDF is image-backed. Its OCR corrupts Ferrell’s phonemic `ḍ` and `ł` on many pages, sometimes producing replacement characters, digits, `*`, or plausible-looking ASCII. During project ingestion, Part 1, Part 2, and the addenda were preserved separately as page-linked review data while every OCR spelling was quarantined from runtime lookup and model grounding. The downloadable starter kit deliberately omits the original PDF and raw OCR corpus. Only page-image-reviewed lexical records should ever be promoted. The ten addendum lines have been transcribed into 11 structured runtime senses/forms in `lib/ferrell-reviewed-entries.json`; the grammar rules in `lib/ferrell-language-pack.ts` were checked manually against their cited pages.

Source: Raleigh Ferrell, *Paiwan Dictionary*, Pacific Linguistics Series C No. 73, The Australian National University (1982), DOI [10.15144/PL-C73](https://doi.org/10.15144/PL-C73). The supplied online edition states [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/); extracted or adapted dictionary data should retain attribution, describe changes, and remain under the same terms. Legal openness does not replace Paiwan community review for personal names, ceremonial vocabulary, culturally sensitive material, or historical labels.

Do not use provisional translations as the sole source for medical, legal, emergency, or other critical decisions.
