#!/bin/sh

set -eu

RUKAIKAI_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cd "$RUKAIKAI_DIR"

if ! command -v node >/dev/null 2>&1; then
  echo "Install Node.js 22.13 or newer from https://nodejs.org/en/download"
  exit 1
fi

if ! node -e 'const [major, minor] = process.versions.node.split(".").map(Number); process.exit(major > 22 || (major === 22 && minor >= 13) ? 0 : 1)'; then
  echo "Node.js 22.13 or newer is required. Your version is $(node --version)."
  exit 1
fi

if [ -f .env.local ]; then
  echo "Using the custom provider and model settings in .env.local."
  echo "Make sure that local model provider is already running."
else
  if ! command -v ollama >/dev/null 2>&1; then
    echo "Install Ollama from https://ollama.com/download"
    exit 1
  fi

  if ! ollama list >/dev/null 2>&1; then
    echo "Ollama is installed but its local server is not running."
    echo "Run 'ollama serve' in another terminal, then start RuKaiKai again."
    exit 1
  fi

  if ! ollama show qwen3:4b-instruct >/dev/null 2>&1; then
    echo "Downloading Qwen 3 4B Instruct (about 2.5 GB)..."
    ollama pull qwen3:4b-instruct
  fi
fi

if [ ! -f node_modules/.package-lock.json ]; then
  npm install --no-audit --no-fund
fi

export RUKAIKAI_MODE="local"

(
  i=0
  while [ "$i" -lt 45 ]; do
    if curl -fsS "http://127.0.0.1:5173/api/health" >/dev/null 2>&1; then
      if command -v xdg-open >/dev/null 2>&1; then
        xdg-open "http://127.0.0.1:5173" >/dev/null 2>&1 || true
      fi
      exit 0
    fi
    i=$((i + 1))
    sleep 1
  done
) &

npm run dev
