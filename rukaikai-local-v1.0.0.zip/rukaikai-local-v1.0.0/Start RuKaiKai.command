#!/bin/bash

set -e

RUKAIKAI_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$RUKAIKAI_DIR"

echo "RuKaiKai Local"
echo "==============="

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js 22.13 or newer is required. Opening the official download page..."
  open "https://nodejs.org/en/download"
  read -r -p "Install Node.js, then run this launcher again. Press Return to close."
  exit 1
fi

if ! node -e 'const [major, minor] = process.versions.node.split(".").map(Number); process.exit(major > 22 || (major === 22 && minor >= 13) ? 0 : 1)'; then
  echo "Node.js 22.13 or newer is required. Your version is $(node --version)."
  open "https://nodejs.org/en/download"
  read -r -p "Update Node.js, then run this launcher again. Press Return to close."
  exit 1
fi

if [ -f .env.local ]; then
  echo "Using the custom provider and model settings in .env.local."
  echo "Make sure that local model provider is already running."
else
  if ! command -v ollama >/dev/null 2>&1; then
    echo "Ollama is required. Opening the official download page..."
    open "https://ollama.com/download"
    read -r -p "Install Ollama, then run this launcher again. Press Return to close."
    exit 1
  fi

  open -a Ollama >/dev/null 2>&1 || true
  OLLAMA_READY=0
  for _ in $(seq 1 30); do
    if ollama list >/dev/null 2>&1; then
      OLLAMA_READY=1
      break
    fi
    sleep 1
  done
  if [ "$OLLAMA_READY" -ne 1 ]; then
    echo "Ollama is installed but its local server did not start."
    read -r -p "Open Ollama, then run this launcher again. Press Return to close."
    exit 1
  fi
  echo "Checking the recommended local model..."
  if ! ollama show qwen3:4b-instruct >/dev/null 2>&1; then
    echo "Downloading Qwen 3 4B Instruct. This is about 2.5 GB and happens once."
    ollama pull qwen3:4b-instruct
  fi
fi

if [ ! -f node_modules/.package-lock.json ]; then
  echo "Installing RuKaiKai packages. This happens on the first start."
  npm install --no-audit --no-fund
fi

export RUKAIKAI_MODE="local"

(
  for _ in $(seq 1 45); do
    if curl -fsS "http://127.0.0.1:5173/api/health" >/dev/null 2>&1; then
      open "http://127.0.0.1:5173"
      exit 0
    fi
    sleep 1
  done
) &

echo "Starting RuKaiKai. Keep this window open; press Ctrl+C to stop."
npm run dev
