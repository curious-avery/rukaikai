import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "RuKaiKai · Paiwan language lab",
  description:
    "Explore how LLMs can support the preservation and revitalization of under-resourced and endangered languages, beginning with Paiwan.",
  icons: {
    icon: "/brand/rukaikai-logo.png",
    shortcut: "/brand/rukaikai-logo.png",
    apple: "/brand/rukaikai-logo.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
