import { NextResponse } from "next/server";

import {
  fetchLocalLlm,
  getLocalLlmConfig,
  getRuKaiKaiMode,
  modelIsAvailable,
} from "@/lib/local-llm";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const mode = getRuKaiKaiMode(request.url);
  let config: ReturnType<typeof getLocalLlmConfig>;
  try {
    config = getLocalLlmConfig();
  } catch {
    if (mode === "demo") {
      return NextResponse.json(
        {
          status: "demo",
          mode,
          provider: "ollama",
          providerLabel: "Ollama",
          model: "qwen3:4b-instruct",
          installed: [],
          message: "The hosted source demo does not contact a local model.",
        },
        { headers: { "Cache-Control": "no-store" } },
      );
    }
    return NextResponse.json(
      {
        status: "offline",
        mode,
        provider: "openai-compatible",
        providerLabel: "Local model",
        model: "not configured",
        installed: [],
        message: "The local model connection settings are invalid.",
      },
      { headers: { "Cache-Control": "no-store" } },
    );
  }

  if (mode === "demo") {
    return NextResponse.json(
      {
        status: "demo",
        mode,
        provider: config.provider,
        providerLabel: config.providerLabel,
        model: config.model,
        installed: [],
        message: "The hosted source demo does not contact a local model.",
      },
      { headers: { "Cache-Control": "no-store" } },
    );
  }

  try {
    const response = await fetchLocalLlm(
      "/models",
      { cache: "no-store" },
      4_000,
    );

    if (!response.ok) {
      throw new Error(`${config.providerLabel} returned ${response.status}.`);
    }

    const payload = (await response.json()) as {
      data?: Array<{ id?: string }>;
    };
    const installed = (payload.data ?? [])
      .map((entry) => entry.id ?? "")
      .filter(Boolean);
    const ready = modelIsAvailable(installed, config.model, config.provider);

    return NextResponse.json(
      {
        status: ready ? "ready" : "model-missing",
        mode,
        provider: config.provider,
        providerLabel: config.providerLabel,
        model: config.model,
        installed,
        message: ready
          ? `${config.model} is available through ${config.providerLabel}.`
          : `${config.providerLabel} is running, but ${config.model} is not available.`,
      },
      { headers: { "Cache-Control": "no-store" } },
    );
  } catch {
    return NextResponse.json(
      {
        status: "offline",
        mode,
        provider: config.provider,
        providerLabel: config.providerLabel,
        model: config.model,
        installed: [],
        message: `${config.providerLabel} is not reachable from the local RuKaiKai server.`,
      },
      { headers: { "Cache-Control": "no-store" } },
    );
  }
}
