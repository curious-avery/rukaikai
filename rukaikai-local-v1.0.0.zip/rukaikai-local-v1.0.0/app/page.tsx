import { TranslatorWorkspace } from "@/app/translator-workspace";
import {
  ferrellRuleCards,
  ferrellSource,
} from "@/lib/ferrell-language-pack";
import { dictionaryEntryCount } from "@/lib/paiwan-dictionary.server";
import { reviewedPairs } from "@/lib/paiwan-language-pack";

export default function Home() {
  const useBrowserSourceDemo =
    process.env.RUKAIKAI_MODE?.trim().toLowerCase() === "demo";

  return (
    <TranslatorWorkspace
      dictionaryEntryCount={dictionaryEntryCount}
      examples={reviewedPairs}
      ferrell={ferrellSource}
      grammarRules={ferrellRuleCards}
      staticDemo={useBrowserSourceDemo}
    />
  );
}
