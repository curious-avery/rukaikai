"use client";

/* eslint-disable @next/next/no-img-element */

import {
  ArrowDown,
  ArrowLeftRight,
  BookOpenText,
  CheckCircle2,
  CircleAlert,
  Download,
  ExternalLink,
  FileCheck2,
  Languages,
  LibraryBig,
  LoaderCircle,
  RefreshCw,
  ShieldCheck,
  Volume2,
} from "lucide-react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";

import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { LocalDownloadSection } from "@/components/local-download-section";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import type {
  ReviewedPair,
  TranslationDirection,
} from "@/lib/paiwan-language-pack";
import type {
  FerrellRuleCard,
  FerrellSource,
} from "@/lib/ferrell-language-pack";
import { translateWithSourceDemo } from "@/lib/source-demo-translation";

type HealthStatus =
  | "checking"
  | "demo"
  | "ready"
  | "model-missing"
  | "offline";

type HealthState = {
  status: HealthStatus;
  mode: "demo" | "local";
  provider: "ollama" | "lm-studio" | "openai-compatible";
  providerLabel: string;
  model: string;
  installed: string[];
  message: string;
};

type TranslationStatus =
  | "reference"
  | "ferrell"
  | "dictionary"
  | "local-required"
  | "draft"
  | "insufficient";

type TranslationResult = {
  translation: string;
  alternatives: string[];
  status: TranslationStatus;
  note: string;
  warning: string | null;
  source:
    | "language-pack"
    | "ferrell-dictionary"
    | "dictionary"
    | "demo"
    | "local-model"
    | "lm-studio";
  model: string | null;
  evidenceCount: number;
};

type ModelContextDocument = Document & {
  modelContext?: {
    registerTool: (
      tool: {
        name: string;
        title: string;
        description: string;
        inputSchema: object;
        annotations: {
          readOnlyHint: boolean;
          untrustedContentHint: boolean;
        };
        execute: (input: unknown) => Promise<unknown>;
      },
      options?: { signal?: AbortSignal },
    ) => unknown;
  };
};

const staticDemoHealth: HealthState = {
  status: "demo",
  mode: "demo",
  provider: "ollama",
  providerLabel: "Ollama",
  model: "qwen3:4b-instruct",
  installed: [],
  message: "The hosted source demo works in this browser without contacting a server or local model.",
};

function getHealthFallback(): HealthState {
  const local = new Set(["localhost", "127.0.0.1", "::1"]).has(
    window.location.hostname.toLowerCase(),
  );
  return {
    status: local ? "offline" : "demo",
    mode: local ? "local" : "demo",
    provider: "ollama",
    providerLabel: "Ollama",
    model: "qwen3:4b-instruct",
    installed: [],
    message: local
      ? "Ollama is not reachable from the local RuKaiKai server."
      : "The hosted source demo does not contact a local model.",
  };
}

const statusLabels: Record<TranslationStatus, string> = {
  reference: "Study reference",
  ferrell: "Ferrell source",
  dictionary: "Word-list match",
  "local-required": "Local edition",
  draft: "Unverified model draft",
  insufficient: "Not enough evidence",
};

const statusClasses: Record<TranslationStatus, string> = {
  reference: "status-source",
  ferrell: "status-source",
  dictionary: "status-source",
  "local-required": "status-local",
  draft: "status-draft",
  insufficient: "status-warning",
};

function sourceLanguage(direction: TranslationDirection) {
  return direction === "paiwan-to-english" ? "Paiwan" : "English";
}

function targetLanguage(direction: TranslationDirection) {
  return direction === "paiwan-to-english" ? "English" : "Paiwan";
}

function nextDirection(direction: TranslationDirection): TranslationDirection {
  return direction === "paiwan-to-english"
    ? "english-to-paiwan"
    : "paiwan-to-english";
}

function healthLabel(status: HealthStatus) {
  switch (status) {
    case "ready":
      return "Local model ready";
    case "demo":
      return "Online source demo";
    case "model-missing":
      return "Dictionary ready";
    case "offline":
      return "Dictionary ready";
    default:
      return "Checking model";
  }
}

function healthBadgeClass(status: HealthStatus) {
  if (status === "ready") {
    return "health-ready";
  }
  if (status === "demo") {
    return "health-demo";
  }
  if (status === "offline" || status === "model-missing") {
    return "health-dictionary";
  }
  return "border-border bg-card text-muted-foreground";
}

function withAssetBasePath(path: string, assetBasePath: string) {
  const base = assetBasePath.trim().replace(/\/+$/, "");
  if (!base || base === "/") return path;

  const normalizedBase =
    base.startsWith("/") || /^(?:https?:)?\/\//.test(base) ? base : `/${base}`;
  return `${normalizedBase}${path}`;
}

export function TranslatorWorkspace({
  dictionaryEntryCount,
  examples,
  ferrell,
  grammarRules,
  staticDemo = false,
  assetBasePath = "",
}: {
  dictionaryEntryCount: number;
  examples: readonly ReviewedPair[];
  ferrell: FerrellSource;
  grammarRules: readonly FerrellRuleCard[];
  staticDemo?: boolean;
  assetBasePath?: string;
}) {
  const starter = examples[1] ?? examples[0];
  const logoPath = withAssetBasePath(
    "/brand/rukaikai-logo.png",
    assetBasePath,
  );
  const [direction, setDirection] =
    useState<TranslationDirection>("paiwan-to-english");
  const [source, setSource] = useState(starter?.paiwan ?? "situ sun?");
  const [result, setResult] = useState<TranslationResult | null>(
    starter
      ? {
          translation: starter.english,
          alternatives: [],
          status: "reference",
          note: "Published reference sentence from the RuKaiKai study.",
          warning: null,
          source: "language-pack",
          model: null,
          evidenceCount: 0,
        }
      : null,
  );
  const [protectedTerms, setProtectedTerms] = useState("");
  const [health, setHealth] = useState<HealthState>(() =>
    staticDemo
      ? staticDemoHealth
      : {
          status: "checking",
          mode: "local",
          provider: "ollama",
          providerLabel: "Ollama",
          model: "qwen3:4b-instruct",
          installed: [],
          message: "Checking the local model…",
        },
  );
  const [isTranslating, setIsTranslating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const requestVersion = useRef(0);
  const activeRequest = useRef<AbortController | null>(null);
  const isLocalRuntime =
    health.status !== "checking" && health.mode === "local";

  async function checkHealth() {
    if (staticDemo) {
      setHealth(staticDemoHealth);
      return;
    }
    setHealth((current) => ({ ...current, status: "checking" }));
    try {
      const response = await fetch("/api/health", { cache: "no-store" });
      const payload = (await response.json()) as HealthState;
      setHealth(payload);
    } catch {
      setHealth(getHealthFallback());
    }
  }

  useEffect(() => {
    if (staticDemo) return;

    let active = true;
    void fetch("/api/health", { cache: "no-store" })
      .then((response) => response.json() as Promise<HealthState>)
      .then((payload) => {
        if (active) setHealth(payload);
      })
      .catch(() => {
        if (active) setHealth(getHealthFallback());
      });
    return () => {
      active = false;
    };
  }, [staticDemo]);

  const cancelPendingTranslation = useCallback(() => {
    requestVersion.current += 1;
    activeRequest.current?.abort();
    activeRequest.current = null;
    setIsTranslating(false);
  }, []);

  const performTranslation = useCallback(
    async (
      text: string,
      requestedDirection: TranslationDirection,
      namesToPreserve = "",
    ) => {
      const cleanText = text.trim();
      if (!cleanText) {
        throw new Error("Enter text to translate.");
      }

      activeRequest.current?.abort();
      const controller = new AbortController();
      activeRequest.current = controller;
      const version = requestVersion.current + 1;
      requestVersion.current = version;
      setSource(cleanText);
      setDirection(requestedDirection);
      setError(null);
      setResult(null);
      setIsTranslating(true);

      try {
        if (staticDemo) {
          const payload = translateWithSourceDemo(
            cleanText,
            requestedDirection,
            namesToPreserve.trim(),
          );
          if (requestVersion.current !== version) {
            throw new Error("Translation was replaced by a newer request.");
          }
          setResult(payload);
          await new Promise<void>((resolve) => {
            requestAnimationFrame(() => resolve());
          });
          return payload;
        }

        const response = await fetch("/api/translate", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            text: cleanText,
            direction: requestedDirection,
            protectedTerms: namesToPreserve.trim(),
          }),
          signal: controller.signal,
        });
        const payload = (await response.json()) as
          | TranslationResult
          | { error?: { message?: string } };

        if (!response.ok || !("translation" in payload)) {
          throw new Error(
            "error" in payload
              ? payload.error?.message ?? "Translation failed."
              : "Translation failed.",
          );
        }

        if (requestVersion.current !== version) {
          throw new Error("Translation was replaced by a newer request.");
        }
        setResult(payload);
        await new Promise<void>((resolve) => {
          requestAnimationFrame(() => resolve());
        });
        return payload;
      } catch (translationError) {
        if (controller.signal.aborted || requestVersion.current !== version) {
          throw new Error("Translation was replaced by a newer request.");
        }
        const message =
          translationError instanceof Error
            ? translationError.message
            : "Translation failed.";
        setError(message);
        throw translationError;
      } finally {
        if (requestVersion.current === version) {
          setIsTranslating(false);
          activeRequest.current = null;
        }
      }
    },
    [staticDemo],
  );

  useEffect(() => {
    const context = (document as ModelContextDocument).modelContext;
    if (!context?.registerTool) return;

    const lifecycle = new AbortController();
    const registration = context.registerTool(
      {
        name: "translate_text",
        title: "Translate with RuKaiKai",
        description:
          "Translate text between Paiwan and English using RuKaiKai's supplied word list, published references, checked Ferrell grammar guide, and an optional local model. Updates the visible translator.",
        inputSchema: {
          type: "object",
          properties: {
            text: {
              type: "string",
              minLength: 1,
              maxLength: 1200,
              description: "The source text to translate.",
            },
            direction: {
              type: "string",
              enum: ["paiwan-to-english", "english-to-paiwan"],
            },
            protectedTerms: {
              type: "string",
              maxLength: 300,
              description: "Optional names or exact spellings to preserve.",
            },
          },
          required: ["text", "direction"],
          additionalProperties: false,
        },
        annotations: {
          readOnlyHint: false,
          untrustedContentHint: true,
        },
        async execute(input) {
          const value = input as {
            text?: unknown;
            direction?: unknown;
            protectedTerms?: unknown;
          };
          if (
            typeof value.text !== "string" ||
            !value.text.trim() ||
            value.text.length > 1200 ||
            (value.direction !== "paiwan-to-english" &&
              value.direction !== "english-to-paiwan") ||
            (value.protectedTerms !== undefined &&
              (typeof value.protectedTerms !== "string" ||
                value.protectedTerms.length > 300))
          ) {
            throw new Error("Provide text and a valid translation direction.");
          }

          const translated = await performTranslation(
            value.text,
            value.direction,
            typeof value.protectedTerms === "string" ? value.protectedTerms : "",
          );
          return {
            translation: translated.translation,
            alternatives: translated.alternatives,
            status: translated.status,
            warning: translated.warning,
            source: translated.source,
          };
        },
      },
      { signal: lifecycle.signal },
    );

    void Promise.resolve(registration).catch(() => {
      // WebMCP support is optional; the visible interface remains fully usable.
    });

    return () => lifecycle.abort();
  }, [performTranslation]);

  const outputDescription = useMemo(() => {
    if (!result) return "Your translation will appear here.";
    if (result.status === "reference") {
      return "Matches a published sentence from the RuKaiKai study.";
    }
    if (result.status === "ferrell") {
      return "Matches a page-image-checked Kulalau entry from Ferrell’s 1982 addenda.";
    }
    if (result.status === "dictionary") {
      return result.alternatives.length
        ? "Exact supplied word-list match. More than one entry is listed, so context matters."
        : "Exact supplied word-list match, reproduced without using the model.";
    }
    if (result.status === "local-required") {
      return "The hosted demo found no exact sourced match. The local edition can create a clearly labeled model draft.";
    }
    if (result.status === "insufficient") {
      return "The current language pack did not support a responsible translation.";
    }
    return result.source === "local-model" || result.source === "lm-studio"
      ? `Drafted locally with ${result.model ?? health.model}. Review before reuse.`
      : "Grounded in the supplied language resources.";
  }, [health.model, result]);

  function swapLanguages() {
    const swappedDirection = nextDirection(direction);
    cancelPendingTranslation();
    setDirection(swappedDirection);
    if (result?.translation) {
      setSource(result.translation);
    }
    setResult(null);
    setProtectedTerms("");
    setError(null);
  }

  function selectSourceLanguage(value: string) {
    const requested: TranslationDirection =
      value === "english" ? "english-to-paiwan" : "paiwan-to-english";
    if (requested !== direction) swapLanguages();
  }

  function loadExample(pair: ReviewedPair) {
    cancelPendingTranslation();
    setDirection("paiwan-to-english");
    setSource(pair.paiwan);
    setResult({
      translation: pair.english,
      alternatives: [],
      status: "reference",
      note: "Published reference sentence from the RuKaiKai study.",
      warning: null,
      source: "language-pack",
      model: null,
      evidenceCount: 0,
    });
    setError(null);
    document.querySelector("#translator")?.scrollIntoView({ behavior: "smooth" });
  }

  function speakTranslation() {
    if (
      !result?.translation ||
      targetLanguage(direction) !== "English" ||
      !("speechSynthesis" in window)
    ) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(result.translation);
    utterance.lang = "en-US";
    window.speechSynthesis.speak(utterance);
  }

  return (
    <main className="min-h-screen bg-background text-foreground">
      <div className="word-current" aria-hidden="true">
        <span>ui! na venala ken.</span>
        <span>language lives when people use it</span>
        <span>situ sun?</span>
        <span>words carry memory</span>
      </div>

      <div className="mx-auto grid min-h-[calc(100vh-38px)] max-w-[1480px] lg:grid-cols-[280px_minmax(0,1fr)]">
        <aside className="flex flex-col border-b border-border bg-sidebar px-5 py-5 lg:border-r lg:border-b-0 lg:px-7 lg:py-8">
          <div className="flex items-center justify-between gap-4 lg:block">
            <div className="brand-lockup">
              <div className="brand-mark-frame">
                <img
                  src={logoPath}
                  alt=""
                  width={377}
                  height={382}
                  className="brand-mark"
                  aria-hidden="true"
                />
              </div>
              <div>
                <p className="brand-wordmark">RuKaiKai</p>
                <p className="brand-subtitle">Paiwan language lab</p>
              </div>
            </div>
            <Badge
              variant="outline"
              className={`px-2.5 py-1 lg:mt-7 ${healthBadgeClass(health.status)}`}
            >
              <span
                className={`size-1.5 rounded-full ${
                  health.status === "ready"
                    ? "bg-teal-500"
                    : health.status === "checking"
                      ? "animate-pulse bg-slate-400"
                      : "bg-amber-500"
                }`}
              />
              {healthLabel(health.status)}
            </Badge>
          </div>

          <nav className="mt-8 hidden space-y-2 lg:block" aria-label="Workspace">
            <a
              href="#translator"
              className="flex items-center gap-3 rounded-xl bg-sidebar-accent px-3 py-3 font-semibold text-sidebar-accent-foreground"
            >
              <Languages className="size-5" />
              Translator
            </a>
            <a
              href="#run-local"
              className="flex items-center gap-3 rounded-xl px-3 py-3 text-muted-foreground transition hover:bg-sidebar-accent hover:text-foreground"
            >
              <Download className="size-5" />
              Run locally
            </a>
            <a
              href="#language-pack"
              className="flex items-center gap-3 rounded-xl px-3 py-3 text-muted-foreground transition hover:bg-sidebar-accent hover:text-foreground"
            >
              <BookOpenText className="size-5" />
              Language pack
            </a>
            <a
              href="#ferrell-source"
              className="flex items-center gap-3 rounded-xl px-3 py-3 text-muted-foreground transition hover:bg-sidebar-accent hover:text-foreground"
            >
              <LibraryBig className="size-5" />
              Ferrell source
            </a>
          </nav>

          <div className="mt-auto hidden rounded-2xl border border-border bg-card p-4 lg:block">
            <ShieldCheck className="brand-accent-icon size-5" aria-hidden="true" />
            <p className="mt-3 font-bold">A careful first draft</p>
            <p className="mt-1 text-sm leading-5 text-muted-foreground">
              Every model-generated translation is marked as an unverified draft.
            </p>
          </div>
        </aside>

        <section className="px-4 py-5 sm:px-7 sm:py-8 xl:px-12" id="translator">
          <header className="hero-intro mb-6">
            <div className="hero-copy">
              <p className="eyebrow">Translation workspace</p>
              <h1 className="mt-2 max-w-3xl text-3xl font-black tracking-[-0.045em] sm:text-5xl">
                Carry meaning across languages.
              </h1>
              <p className="mt-3 max-w-2xl text-base leading-7 text-muted-foreground">
                RuKaiKai’s purpose is to explore how large language models (LLMs)
                can support the preservation and revitalization of under-resourced
                and endangered languages, beginning with Paiwan.
              </p>
              <p className="mt-2 max-w-2xl text-base leading-7 text-muted-foreground">
                {isLocalRuntime
                  ? "Use source-backed matches and add clearly labeled AI drafts with the model running on this computer."
                  : "Try exact, source-backed matches online—or download RuKaiKai to add private AI drafts on your own computer."}
              </p>
              <div className="hero-actions mt-4">
                <a href="#translator" className="hero-link-primary">
                  {isLocalRuntime ? "Use the local translator" : "Try the online demo"}
                </a>
                <a href="#run-local" className="hero-link-secondary">
                  {isLocalRuntime ? (
                    <>
                      <CheckCircle2 className="size-4" /> Local edition is running
                    </>
                  ) : (
                    <>
                      <Download className="size-4" /> Download the local kit
                    </>
                  )}
                </a>
              </div>
              <p className="mt-4 max-w-2xl rounded-xl border border-border bg-muted/45 px-3 py-2.5 text-sm leading-6 text-muted-foreground">
                <strong className="text-foreground">
                  RuKaiKai was developed in consultation with Paiwan chief{" "}
                  <span lang="zh-Hant">葛關復勇</span> (Ge,Kuan-Fu-Yung), a faculty
                  member at National Kaohsiung University of Science and Technology.
                </strong>{" "}
                This acknowledgment records consultation only; it does not imply
                individual or institutional endorsement, certification, or
                community-wide validation.
              </p>
            </div>
            <div className="hero-emblem" aria-label="RuKaiKai project emblem">
              <span className="hero-emblem-kicker">Language · source · memory</span>
              <img
                src={logoPath}
                alt="RuKaiKai circular emblem"
                width={377}
                height={382}
                className="hero-emblem-image"
              />
              <Badge className="hero-status-badge">
                {health.status === "demo"
                  ? "Online source demo"
                  : health.status === "ready"
                    ? `${health.model} · ${health.providerLabel}`
                    : "Dictionary + grammar mode"}
              </Badge>
            </div>
          </header>

          {health.status === "demo" && (
            <Alert className="source-demo-alert mb-5">
              <BookOpenText />
              <AlertTitle>Online source demo</AlertTitle>
              <AlertDescription className="text-current opacity-80">
                <p>
                  Exact word-list matches, published examples, and checked Ferrell
                  references work here. For a new sentence, use the downloadable
                  local edition with Ollama.
                </p>
                <a className="notice-link" href="#run-local">
                  Set up the local edition
                </a>
              </AlertDescription>
            </Alert>
          )}

          {(health.status === "offline" || health.status === "model-missing") && (
            <Alert className="dictionary-alert mb-5">
              <BookOpenText />
              <AlertTitle>Dictionary mode is ready</AlertTitle>
              <AlertDescription className="text-current opacity-80">
                <p>
                  {health.status === "offline"
                    ? `Exact sourced matches work now. Keep ${health.providerLabel} running on this computer to add local model drafts.`
                    : `Exact sourced matches work now. Download or load ${health.model} in ${health.providerLabel} to add model drafts.`}
                </p>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => void checkHealth()}
                  className="model-refresh-button mt-2"
                >
                  <RefreshCw className="size-4" />
                  Check local model again
                </Button>
              </AlertDescription>
            </Alert>
          )}

          <div className="translator-shell">
            <form
              className="grid gap-0 lg:grid-cols-[minmax(0,1fr)_68px_minmax(0,1fr)]"
              onSubmit={(event) => {
                event.preventDefault();
                void performTranslation(source, direction, protectedTerms).catch(
                  () => undefined,
                );
              }}
            >
              <section className="p-5 sm:p-7">
                <div className="mb-5 flex items-center justify-between gap-3">
                  <div>
                    <p className="panel-label">From</p>
                    <Select
                      value={sourceLanguage(direction).toLowerCase()}
                      onValueChange={selectSourceLanguage}
                    >
                      <SelectTrigger
                        className="mt-2 h-11 w-[190px] border-border bg-card text-base font-bold"
                        aria-label="Source language"
                      >
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="paiwan">Paiwan</SelectItem>
                        <SelectItem value="english">English</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <span className="source-pill">
                    Source
                  </span>
                </div>

                <label htmlFor="source-text" className="sr-only">
                  Text to translate
                </label>
                <Textarea
                  id="source-text"
                  value={source}
                  onChange={(event) => {
                    cancelPendingTranslation();
                    setSource(event.target.value);
                    setResult(null);
                    setError(null);
                  }}
                  onKeyDown={(event) => {
                    if (event.key === "Enter" && (event.metaKey || event.ctrlKey)) {
                      event.preventDefault();
                      void performTranslation(
                        source,
                        direction,
                        protectedTerms,
                      ).catch(() => undefined);
                    }
                  }}
                  maxLength={1200}
                  lang={sourceLanguage(direction) === "Paiwan" ? "pwn" : "en"}
                  className="min-h-[160px] resize-none rounded-lg border-0 bg-transparent p-1 text-2xl font-semibold leading-relaxed shadow-none focus-visible:ring-2 focus-visible:ring-ring/50 sm:text-3xl"
                  spellCheck={false}
                />
                <div className="mt-3">
                  <label
                    htmlFor="protected-terms"
                    className="text-sm font-bold text-foreground/80"
                  >
                    Names or spellings to preserve <span className="font-normal text-muted-foreground">(optional)</span>
                  </label>
                  <Input
                    id="protected-terms"
                    value={protectedTerms}
                    onChange={(event) => {
                      cancelPendingTranslation();
                      setProtectedTerms(event.target.value);
                      setResult(null);
                      setError(null);
                    }}
                    maxLength={300}
                    placeholder="e.g. Muakay, Ljavuras"
                    className="mt-2 h-10 bg-background/70"
                  />
                </div>
                <div className="mt-5 flex items-center justify-between gap-3 border-t border-dashed border-border pt-4 text-sm text-muted-foreground">
                  <span>{source.length.toLocaleString()} / 1,200</span>
                  <Button
                    className="h-11 rounded-xl px-5 font-bold"
                    type="submit"
                    disabled={!source.trim() || isTranslating}
                  >
                    {isTranslating ? (
                      <LoaderCircle className="size-4 animate-spin" />
                    ) : (
                      <Languages className="size-4" />
                    )}
                    {isTranslating ? "Translating…" : "Translate"}
                  </Button>
                </div>
              </section>

              <div className="relative grid place-items-center border-y border-border bg-muted/50 py-3 lg:border-x lg:border-y-0 lg:py-0">
                <div className="absolute hidden h-full w-px bg-border lg:block" />
                <Button
                  type="button"
                  variant="outline"
                  size="icon-lg"
                  onClick={swapLanguages}
                  className="relative rounded-full bg-card text-primary shadow-sm"
                  aria-label={`Swap to ${targetLanguage(direction)} as the source language`}
                >
                  <ArrowDown className="size-5 lg:hidden" aria-hidden="true" />
                  <ArrowLeftRight
                    className="hidden size-5 lg:block"
                    aria-hidden="true"
                  />
                </Button>
              </div>

              <section className="relative min-h-[340px] bg-output p-5 sm:p-7">
                <div className="mb-5 flex items-start justify-between gap-3">
                  <div>
                    <p className="panel-label">To</p>
                    <p className="mt-3 text-xl font-black">
                      {targetLanguage(direction)}
                    </p>
                  </div>
                  {result && (
                    <Badge
                      variant="outline"
                      className={statusClasses[result.status]}
                    >
                      {(result.status === "reference" ||
                        result.status === "ferrell" ||
                        result.status === "dictionary") && (
                        <CheckCircle2 className="size-3" />
                      )}
                      {statusLabels[result.status]}
                    </Badge>
                  )}
                </div>

                <output
                  aria-live="polite"
                  aria-busy={isTranslating}
                  lang={targetLanguage(direction) === "Paiwan" ? "pwn" : "en"}
                  className="block min-h-[180px] text-3xl font-black leading-snug tracking-[-0.025em] sm:text-4xl"
                >
                  {isTranslating ? (
                    <span className="flex items-center gap-3 text-xl font-semibold text-muted-foreground">
                      <LoaderCircle className="size-5 animate-spin text-primary" />
                      {health.status === "demo"
                        ? "Checking sources…"
                        : `Asking ${health.model}…`}
                    </span>
                  ) : result?.translation ? (
                    result.translation
                  ) : result?.status === "local-required" ? (
                    <span className="text-xl font-semibold text-muted-foreground">
                      Run the local edition to draft a new sentence with a model.
                    </span>
                  ) : result?.status === "insufficient" ? (
                    <span className="text-xl font-semibold text-muted-foreground">
                      Not enough evidence to translate this safely.
                    </span>
                  ) : (
                    <span className="text-xl font-semibold text-muted-foreground">
                      Your translation will appear here.
                    </span>
                  )}
                </output>

                {result?.alternatives.length ? (
                  <div className="alternative-card mb-5">
                    <p className="text-sm font-bold">
                      Other exact listed forms
                    </p>
                    <ul className="mt-2 space-y-1 text-base font-semibold opacity-80">
                      {result.alternatives.map((alternative) => (
                        <li key={alternative}>{alternative}</li>
                      ))}
                    </ul>
                  </div>
                ) : null}

                {error && (
                  <Alert variant="destructive" className="mb-4 bg-card">
                    <CircleAlert />
                    <AlertTitle>Translation unavailable</AlertTitle>
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                {result?.warning && (
                  <Alert className="mb-4 border-amber-300 bg-amber-50 dark:border-amber-800 dark:bg-amber-950/60">
                    <CircleAlert />
                    <AlertTitle>Community review recommended</AlertTitle>
                    <AlertDescription>{result.warning}</AlertDescription>
                  </Alert>
                )}

                <div className="mt-5 flex items-center justify-between gap-3 border-t border-dashed border-border pt-4">
                  <div>
                    <p className="max-w-md text-sm leading-5 text-muted-foreground">
                      {outputDescription}
                    </p>
                    {result?.note && (
                      <p className="mt-1 text-sm font-semibold text-foreground/75">
                        {result.note}
                      </p>
                    )}
                  </div>
                  <Button
                    type="button"
                    size="icon-lg"
                    variant="outline"
                    className="rounded-xl bg-card"
                    aria-label="Listen to translation using the device voice"
                    onClick={speakTranslation}
                    disabled={
                      !result?.translation ||
                      isTranslating ||
                      targetLanguage(direction) !== "English"
                    }
                  >
                    <Volume2 className="size-5" />
                  </Button>
                </div>
              </section>
            </form>
          </div>

          <LocalDownloadSection
            dictionaryEntryCount={dictionaryEntryCount}
            grammarRuleCount={grammarRules.length}
            isLocal={isLocalRuntime}
            assetBasePath={assetBasePath}
          />

          <section
            id="language-pack"
            className="mt-6 grid gap-4 md:grid-cols-3"
            aria-label="Language pack summary"
          >
            <article className="info-card md:col-span-2">
              <p className="panel-label">Try a study reference</p>
              <div className="mt-3 flex flex-wrap gap-2">
                {examples.slice(0, 4).map((pair) => (
                  <button
                    key={pair.paiwan}
                    type="button"
                    lang="pwn"
                    className="rounded-full border border-border bg-background px-3 py-2 text-left text-sm font-semibold transition hover:border-primary hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    onClick={() => loadExample(pair)}
                  >
                    {pair.paiwan}
                  </button>
                ))}
              </div>
              <p className="mt-4 max-w-2xl text-sm leading-5 text-muted-foreground">
                Based on Avery Liu and Theavy So’s RuKaiKai study. This prototype
                includes {dictionaryEntryCount.toLocaleString()} clean pairs from
                the supplied searchable word list, 10 published sentence pairs,
                and {grammarRules.length} page-checked rule cards from Ferrell.
                Exact matches work without a model. The word list and Ferrell source
                stay separate so the app does not invent provenance.
              </p>
            </article>
            <article className="info-card accent-card">
              <p className="panel-label text-white/70">Speech status</p>
              <p className="mt-3 text-lg font-bold text-white">English preview only</p>
              <p className="mt-2 text-sm leading-5 text-white/75">
                Paiwan playback is disabled until a verified Paiwan voice is
                connected.
              </p>
            </article>
          </section>

          <section
            id="ferrell-source"
            className="mt-6 scroll-mt-6"
            aria-labelledby="ferrell-heading"
          >
            <div className="source-header">
              <div>
                <p className="eyebrow">Page-checked historical reference</p>
                <h2
                  id="ferrell-heading"
                  className="mt-2 text-2xl font-black tracking-[-0.035em] sm:text-3xl"
                >
                  Ferrell’s Paiwan Dictionary is now part of the language pack.
                </h2>
              </div>
              <a
                href={ferrell.sourceUrl}
                target="_blank"
                rel="noreferrer"
                className="source-link"
              >
                Open the ANU source
                <ExternalLink className="size-4" aria-hidden="true" />
              </a>
            </div>

            <div className="mt-4 grid gap-4 lg:grid-cols-[minmax(0,1.5fr)_minmax(260px,0.75fr)]">
              <article className="info-card">
                <div className="flex flex-wrap gap-2">
                  <Badge variant="outline">Kulalau base dialect</Badge>
                  <Badge variant="outline">{ferrell.year}</Badge>
                  <Badge variant="outline">{ferrell.license}</Badge>
                </div>
                <p className="mt-4 text-lg font-black">
                  {ferrell.author}, <cite>{ferrell.title}</cite>
                </p>
                <p className="mt-2 max-w-3xl text-sm leading-6 text-muted-foreground">
                  The full Paiwan–English section, abridged English index, and
                  addenda have been preserved by source page for structured review.
                  Ferrell says the dictionary is incomplete and that its English
                  glosses may be narrower than a Paiwan stem’s meaning. Results
                  should therefore be read as sourced evidence, not a universal
                  standard for every Paiwan variety.
                </p>
                <div className="source-stats mt-5">
                  <div>
                    <strong>{ferrell.canonicalEntryPages}</strong>
                    <span>canonical entry pages</span>
                  </div>
                  <div>
                    <strong>{ferrell.englishIndexPages}</strong>
                    <span>abridged index pages</span>
                  </div>
                  <div>
                    <strong>0</strong>
                    <span>OCR spellings auto-promoted</span>
                  </div>
                </div>
              </article>

              <aside className="info-card verification-card">
                <FileCheck2 className="brand-accent-icon size-6" />
                <p className="mt-3 text-lg font-black">Source-safe ingestion</p>
                <p className="mt-2 text-sm leading-6 text-muted-foreground">
                  The scan’s text layer damages Ferrell’s phonemic ḍ and ł. Raw
                  extracted spellings are quarantined until checked against the
                  page image; they cannot silently enter lookup or model evidence.
                </p>
                <p className="mt-3 text-xs font-semibold uppercase tracking-[0.08em] text-muted-foreground">
                  DOI {ferrell.doi}
                </p>
              </aside>
            </div>

            <div className="mt-6">
              <div className="flex items-end justify-between gap-4">
                <div>
                  <p className="panel-label">Checked grammar guide</p>
                  <h3 className="mt-2 text-xl font-black">Rules with page trails</h3>
                </div>
                <span className="text-sm text-muted-foreground">
                  {grammarRules.length} topics
                </span>
              </div>
              <div className="grammar-grid mt-3">
                {grammarRules.map((rule) => (
                  <details className="grammar-card" key={rule.id}>
                    <summary>
                      <span>{rule.title}</span>
                      <span className="page-pill">book {rule.printedPages}</span>
                    </summary>
                    <p>{rule.summary}</p>
                    <p className="mt-3 text-xs font-semibold text-muted-foreground">
                      PDF pages {rule.pdfPages}
                    </p>
                  </details>
                ))}
              </div>
            </div>

            <footer className="source-footer">
              <p>
                Source: {ferrell.author}, <cite>{ferrell.title}</cite>, {ferrell.publisher}, {ferrell.series} ({ferrell.year}).
                Digitization structure and rule summaries by RuKaiKai; changes are
                identified. Dictionary-derived data follows the supplied online
                edition’s {ferrell.license} notice.
              </p>
              <a
                href={ferrell.licenseUrl}
                target="_blank"
                rel="noreferrer"
              >
                License <ExternalLink className="size-3" aria-hidden="true" />
              </a>
            </footer>
          </section>
        </section>
      </div>
    </main>
  );
}
