import vinext from "vinext";
import { defineConfig, loadEnv } from "vite";
import hostingConfig from "./.openai/hosting.json";
import { readExecutionProfile } from "./scripts/execution-profile.mjs";
import { sites } from "./build/sites-vite-plugin";

const SITE_CREATOR_PLACEHOLDER_DATABASE_ID =
  "00000000-0000-4000-8000-000000000000";
const LOCAL_RUNTIME_VAR_KEYS = [
  "RUKAIKAI_MODE",
  "LOCAL_LLM_PROVIDER",
  "LOCAL_LLM_BASE_URL",
  "LOCAL_LLM_MODEL",
  "LOCAL_LLM_TIMEOUT_MS",
  "LM_STUDIO_BASE_URL",
  "LM_STUDIO_MODEL",
  "LM_STUDIO_TIMEOUT_MS",
] as const;
const LOCAL_RUNTIME_SECRET_KEYS = [
  "LOCAL_LLM_API_KEY",
  "LM_STUDIO_API_KEY",
] as const;

const { d1, r2 } = hostingConfig;

// macOS Seatbelt blocks FSEvents, so Codex previews need polling for HMR.
const isCodexSeatbeltSandbox = process.env.CODEX_SANDBOX === "seatbelt";
const managedLinux = readExecutionProfile() === "managed-linux";

export default defineConfig(async ({ command, mode }) => {
  // Use Miniflare's local Request.cf placeholder unless fetching is requested.
  process.env.CLOUDFLARE_CF_FETCH_ENABLED ??= "false";
  process.env.WRANGLER_SEND_METRICS ??= "false";

  // Keep Wrangler and Miniflare state project-local. These are non-secret tool
  // settings; application environment belongs in ignored `.env*` files.
  process.env.WRANGLER_WRITE_LOGS ??= "false";
  process.env.WRANGLER_LOG_PATH ??= ".wrangler/logs";
  process.env.WRANGLER_REGISTRY_PATH ??= ".wrangler/dev-registry";
  process.env.MINIFLARE_REGISTRY_PATH ??= ".wrangler/registry";

  // Wrangler snapshots its log path while the Cloudflare plugin is imported.
  const { cloudflare } = await import("@cloudflare/vite-plugin");

  // Worker code cannot see the launcher's process.env automatically. During
  // local development, pass only RuKaiKai's documented runtime settings into
  // the Worker. Declaring the optional API keys as secrets also stops Wrangler
  // from implicitly exposing unrelated .env.local values. Never add any of
  // these bindings to build config, where a key could enter a deployable artifact.
  const loadedEnv = command === "serve" ? loadEnv(mode, process.cwd(), "") : {};
  const runtimeEnvValue = (key: string) => process.env[key] ?? loadedEnv[key];
  const localRuntimeVars = Object.fromEntries(
    LOCAL_RUNTIME_VAR_KEYS.flatMap((key) => {
      const value = runtimeEnvValue(key);
      return value?.trim() ? [[key, value]] : [];
    }),
  );
  const localRuntimeSecrets = LOCAL_RUNTIME_SECRET_KEYS.filter((key) =>
    runtimeEnvValue(key)?.trim(),
  );
  const localBindingConfig = {
    main: "vinext/server/fetch-handler",
    compatibility_flags: ["nodejs_compat"],
    ...(command === "serve"
      ? {
          vars: localRuntimeVars,
          secrets: { required: localRuntimeSecrets },
        }
      : {}),
    d1_databases: d1
      ? [
          {
            binding: d1,
            database_name: "site-creator-d1",
            database_id: SITE_CREATOR_PLACEHOLDER_DATABASE_ID,
          },
        ]
      : [],
    r2_buckets: r2
      ? [
          {
            binding: r2,
            bucket_name: "site-creator-r2",
          },
        ]
      : [],
  };

  return {
    server: {
      ...(managedLinux
        ? { host: "0.0.0.0", allowedHosts: ["terminal.local"] }
        : { host: "127.0.0.1" }),
      strictPort: true,
      ...(isCodexSeatbeltSandbox ? { watch: { useFsEvents: false, usePolling: true } } : {}),
    },
    plugins: [
      vinext(),
      sites({ mockAuth: !managedLinux }),
      cloudflare({
        viteEnvironment: { name: "rsc", childEnvironments: ["ssr"] },
        inspectorPort: false,
        config: localBindingConfig,
      }),
    ],
  };
});
