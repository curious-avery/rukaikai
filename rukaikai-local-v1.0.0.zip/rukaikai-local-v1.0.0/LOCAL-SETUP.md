# RuKaiKai Local — Start Here

RuKaiKai Local adds private, clearly labeled AI drafts to the source-backed
dictionary and language guide. The recommended model is Qwen 3 4B Instruct,
served by Ollama on the same computer.

## Before the first start

Install both prerequisites:

1. Ollama: <https://ollama.com/download>
2. Node.js 22.13 or newer: <https://nodejs.org/en/download>

Keep Ollama running. RuKaiKai uses only the loopback address
`http://127.0.0.1:11434`; do not expose Ollama to your network or the internet.

## Start RuKaiKai

- **macOS:** double-click `Start RuKaiKai.command`. If macOS blocks it, right-click
  the file, choose **Open**, and confirm once.
- **Windows:** use **Extract All** on the ZIP first, then double-click
  `Start RuKaiKai.bat` inside the extracted folder.
- **Linux:** make sure the Ollama service is running (`ollama serve` when
  needed), then run `./start-rukaikai.sh` from a terminal.

On the first start, the launcher:

1. checks Node.js and Ollama;
2. downloads `qwen3:4b-instruct` through Ollama (about 2.5 GB);
3. installs RuKaiKai's application packages; and
4. opens <http://localhost:5173>.

Later starts reuse the downloaded model and installed packages. Keep the launcher
window open while using RuKaiKai. Press `Ctrl+C` in that window to stop the local
app.

## Manual start

If a launcher does not work, open a terminal in this folder and run:

```sh
ollama pull qwen3:4b-instruct
npm install
npm run dev
```

Then open <http://localhost:5173>.

## What local means

Text sent for a model draft goes from your browser to RuKaiKai on this computer,
then to Ollama on this computer. RuKaiKai does not keep a translation history.
Internet access is needed for the initial software and model downloads, but not
for later inference with an already downloaded model. Allow about 5 GB of free
storage for the 2.5 GB model, application packages, and download caches.

The model output is not a verified translation. Have a fluent Paiwan speaker or
community reviewer check it before reuse, especially for medical, legal,
emergency, ceremonial, or other sensitive language.

## Troubleshooting

### “Ollama is not reachable”

Open the Ollama application on macOS or Windows and leave it running. On Linux,
run `ollama serve` when the service is not already active. Then refresh RuKaiKai.

### “Model is not available”

Run:

```sh
ollama pull qwen3:4b-instruct
```

### The computer is slow or runs out of memory

Close other large applications. A 4B model can run on many recent computers, but
speed depends on memory, processor, and GPU. An 8 GB computer may be slow; 16 GB
or more is more comfortable.

### Use Gemma instead

Run `ollama pull gemma3:4b`, copy `.env.example` to `.env.local`, and change:

```text
LOCAL_LLM_MODEL=gemma3:4b
```

Restart RuKaiKai after changing `.env.local`.

When `.env.local` exists, the launcher assumes you have already installed and
started the provider and model named there; it does not automatically download
the default Qwen model.

### “Port 5173 is already in use”

Close another RuKaiKai launcher window or the other application using port 5173,
then start RuKaiKai again. The fixed port keeps the app bound to a predictable
loopback address.

### A package or model download stopped

Check the internet connection and run the launcher again. It reuses completed
downloads and repairs an incomplete package installation.

## Sources and redistribution

See `SOURCE-NOTICES.md` before redistributing the application or its language
data. The original Ferrell PDF and model weights are not included in this kit.

To verify the downloaded ZIP, compare its checksum with the published `.sha256`
file. On macOS or Linux, run `shasum -a 256 rukaikai-local-v1.0.0.zip`. On
Windows PowerShell, run `Get-FileHash rukaikai-local-v1.0.0.zip -Algorithm SHA256`.
