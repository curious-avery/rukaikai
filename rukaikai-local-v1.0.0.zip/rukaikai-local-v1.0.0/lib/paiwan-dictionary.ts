import rawDictionaryEntries from "@/lib/paiwan-dictionary-data.json";
import rawFerrellReviewedEntries from "@/lib/ferrell-reviewed-entries.json";

import type { TranslationDirection } from "@/lib/paiwan-language-pack";

export type DictionaryEvidence = {
  paiwan: string;
  english: string;
};

export type FerrellReviewedMatch = {
  translation: string;
  sourceForm: string;
  english: string;
  entryPrintedPage: number;
  entryPdfPage: number;
  addendumPdfPage: number;
  dialect: string;
  uncertain: boolean;
};

type FerrellReviewedEntry = {
  forms: string[];
  english: string;
  entryPrintedPage: number;
  entryPdfPage: number;
  addendumPdfPage: number;
  dialect: string;
  uncertain: boolean;
};

type IndexedDictionaryEntry = DictionaryEvidence & {
  index: number;
  paiwanKey: string;
  englishKey: string;
  paiwanTokens: readonly string[];
  englishTokens: readonly string[];
};

type RetrievalOptions = {
  maxEntries?: number;
  maxChars?: number;
};

const DEFAULT_MAX_ENTRIES = 32;
const DEFAULT_MAX_CHARS = 6_000;

const englishStopWords = new Set([
  "a",
  "an",
  "and",
  "are",
  "at",
  "be",
  "for",
  "from",
  "had",
  "has",
  "have",
  "he",
  "her",
  "his",
  "i",
  "in",
  "is",
  "it",
  "my",
  "of",
  "on",
  "or",
  "our",
  "she",
  "that",
  "the",
  "their",
  "these",
  "they",
  "this",
  "those",
  "to",
  "was",
  "we",
  "were",
  "with",
  "you",
  "your",
]);

export function normalizeDictionaryKey(value: string) {
  return value
    .normalize("NFC")
    .replace(/[‘’]/g, "'")
    .trim()
    .replace(/\s+/g, " ")
    .toLocaleLowerCase("en-US");
}

function tokenize(value: string) {
  return (
    normalizeDictionaryKey(value).match(
      /[\p{L}\p{N}]+(?:['’.\-][\p{L}\p{N}]+)*/gu,
    ) ?? []
  );
}

function uniqueTokens(tokens: readonly string[]) {
  return [...new Set(tokens)];
}

function meaningfulQueryTokens(
  value: string,
  direction: TranslationDirection,
) {
  const tokens = uniqueTokens(tokenize(value));
  if (direction !== "english-to-paiwan") return tokens;

  const filtered = tokens.filter((token) => !englishStopWords.has(token));
  return filtered.length ? filtered : tokens;
}

function addEnglishLexicalVariants(tokens: readonly string[]) {
  const variants = new Set(tokens);

  for (const token of tokens) {
    if (token.length <= 3) continue;
    if (token.endsWith("ies") && token.length > 4) {
      variants.add(`${token.slice(0, -3)}y`);
    } else if (/(?:sses|xes|zes|ches|shes)$/.test(token)) {
      variants.add(token.slice(0, -2));
    } else if (token.endsWith("s") && !token.endsWith("ss")) {
      variants.add(token.slice(0, -1));
    }
  }

  return variants;
}

function containsTokenSequence(
  haystack: readonly string[],
  needle: readonly string[],
) {
  if (!needle.length || needle.length > haystack.length) return false;

  for (let start = 0; start <= haystack.length - needle.length; start += 1) {
    if (needle.every((token, offset) => haystack[start + offset] === token)) {
      return true;
    }
  }

  return false;
}

const dictionaryEntries: readonly IndexedDictionaryEntry[] = (
  rawDictionaryEntries as string[][]
).map(([paiwan, english], index) => ({
  paiwan,
  english,
  index,
  paiwanKey: normalizeDictionaryKey(paiwan),
  englishKey: normalizeDictionaryKey(english),
  paiwanTokens: uniqueTokens(tokenize(paiwan)),
  englishTokens: uniqueTokens(tokenize(english)),
}));

function buildExactIndex(
  direction: TranslationDirection,
): ReadonlyMap<string, readonly string[]> {
  const index = new Map<string, string[]>();

  for (const entry of dictionaryEntries) {
    const source =
      direction === "paiwan-to-english" ? entry.paiwanKey : entry.englishKey;
    const target =
      direction === "paiwan-to-english" ? entry.english : entry.paiwan;
    const matches = index.get(source) ?? [];
    if (!matches.includes(target)) matches.push(target);
    index.set(source, matches);
  }

  return index;
}

const paiwanToEnglish = buildExactIndex("paiwan-to-english");
const englishToPaiwan = buildExactIndex("english-to-paiwan");
const ferrellReviewedEntries =
  rawFerrellReviewedEntries as FerrellReviewedEntry[];

export const dictionaryEntryCount = dictionaryEntries.length;

export function findDictionaryMatches(
  text: string,
  direction: TranslationDirection,
) {
  const index =
    direction === "paiwan-to-english" ? paiwanToEnglish : englishToPaiwan;
  return index.get(normalizeDictionaryKey(text)) ?? [];
}

export function findFerrellReviewedMatches(
  text: string,
  direction: TranslationDirection,
): FerrellReviewedMatch[] {
  const key = normalizeDictionaryKey(text);
  const matches: FerrellReviewedMatch[] = [];

  for (const entry of ferrellReviewedEntries) {
    if (direction === "paiwan-to-english") {
      const sourceForm = entry.forms.find(
        (form) => normalizeDictionaryKey(form) === key,
      );
      if (!sourceForm) continue;
      matches.push({
        translation: entry.english,
        sourceForm,
        english: entry.english,
        entryPrintedPage: entry.entryPrintedPage,
        entryPdfPage: entry.entryPdfPage,
        addendumPdfPage: entry.addendumPdfPage,
        dialect: entry.dialect,
        uncertain: entry.uncertain,
      });
      continue;
    }

    if (normalizeDictionaryKey(entry.english) !== key) continue;
    for (const sourceForm of entry.forms) {
      matches.push({
        translation: sourceForm,
        sourceForm,
        english: entry.english,
        entryPrintedPage: entry.entryPrintedPage,
        entryPdfPage: entry.entryPdfPage,
        addendumPdfPage: entry.addendumPdfPage,
        dialect: entry.dialect,
        uncertain: entry.uncertain,
      });
    }
  }

  return matches;
}

export function retrieveDictionaryEvidence(
  text: string,
  direction: TranslationDirection,
  options: RetrievalOptions = {},
) {
  const maxEntries = Math.min(
    Math.max(options.maxEntries ?? DEFAULT_MAX_ENTRIES, 1),
    DEFAULT_MAX_ENTRIES,
  );
  const maxChars = Math.min(
    Math.max(options.maxChars ?? DEFAULT_MAX_CHARS, 100),
    DEFAULT_MAX_CHARS,
  );
  const queryTokens = meaningfulQueryTokens(text, direction);
  const queryTokenSet =
    direction === "english-to-paiwan"
      ? addEnglishLexicalVariants(queryTokens)
      : new Set(queryTokens);

  if (!queryTokens.length) return [];

  const ranked = dictionaryEntries
    .map((entry) => {
      const sourceTokens =
        direction === "paiwan-to-english"
          ? entry.paiwanTokens
          : entry.englishTokens;
      const uniqueSourceTokens = uniqueTokens(sourceTokens);
      const overlap = uniqueSourceTokens.filter((token) =>
        queryTokenSet.has(token),
      ).length;

      if (!overlap) return null;

      const phraseMatch = containsTokenSequence(queryTokens, sourceTokens);
      const score =
        overlap * 20 +
        Math.round((overlap / uniqueSourceTokens.length) * 10) +
        (phraseMatch ? 100 + sourceTokens.length * 5 : 0);

      return { entry, score };
    })
    .filter((item): item is { entry: IndexedDictionaryEntry; score: number } =>
      Boolean(item),
    )
    .sort((left, right) =>
      right.score === left.score
        ? left.entry.index - right.entry.index
        : right.score - left.score,
    );

  const evidence: DictionaryEvidence[] = [];
  let serializedChars = 2;

  for (const { entry } of ranked) {
    if (evidence.length >= maxEntries) break;

    const candidate = { paiwan: entry.paiwan, english: entry.english };
    const candidateChars = JSON.stringify(candidate).length + 1;
    if (serializedChars + candidateChars > maxChars) continue;

    evidence.push(candidate);
    serializedChars += candidateChars;
  }

  return evidence;
}
