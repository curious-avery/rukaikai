export type FerrellRuleCard = {
  id: string;
  title: string;
  summary: string;
  printedPages: string;
  pdfPages: string;
  modelRule: string;
};

export const ferrellSource = {
  title: "Paiwan Dictionary",
  author: "Raleigh Ferrell",
  year: 1982,
  publisher: "Pacific Linguistics, The Australian National University",
  series: "Series C, No. 73",
  doi: "10.15144/PL-C73",
  sourceUrl:
    "https://openresearch-repository.anu.edu.au/items/ddee88ae-ada7-4516-80a4-13e180552902",
  license: "CC BY-SA 4.0",
  licenseUrl: "https://creativecommons.org/licenses/by-sa/4.0/",
  baseDialect: "Kulalau",
  pdfPages: 514,
  canonicalEntryPages: 312,
  englishIndexPages: 135,
  sha256: "92ad7e17139a9caae8e9ef3be3ebec25fe862da0c02ed17fc735018da91a2474",
} as const;

export type FerrellSource = typeof ferrellSource;

export const ferrellRuleCards: readonly FerrellRuleCard[] = [
  {
    id: "scope",
    title: "Kulalau is the default",
    summary:
      "Unmarked entries are Kulalau forms. W, OD, Q, and T mark western, other-dialect, southern, and Tjuabar evidence. Ferrell calls the work incomplete and warns that an English gloss may be narrower than the Paiwan stem.",
    printedPages: "viii, x",
    pdfPages: "8, 10",
    modelRule:
      "Default only unmarked Ferrell evidence to Kulalau. Keep W, OD, Q, and T forms dialect-labeled, and never treat one English gloss as the full semantic range of a Paiwan stem.",
  },
  {
    id: "dictionary-structure",
    title: "Roots, forms, and senses stay separate",
    summary:
      "Part 1 groups senses, derived forms, examples, and cross-references under roots. A cross-listing is not proof that every listed analysis is still productive. Part 2 is only an abridged English index.",
    printedPages: "ix–x",
    pdfPages: "9–10",
    modelRule:
      "Treat Part 1 as canonical and Part 2 only as an English lookup aid. Do not turn cross-listed or frozen material into a productive rule.",
  },
  {
    id: "construction-markers",
    title: "Construction markers connect phrases",
    summary:
      "a marks an equational relationship, nua a genitive or partitive relationship, and tua a relationship that is neither. Paiwan does not directly join two nouns as a compound.",
    printedPages: "12–13",
    pdfPages: "22–23",
    modelRule:
      "Use a for equational phrase relations, nua for genitive or partitive relations, and tua for other non-equational relations. Do not invent direct noun+noun compounds.",
  },
  {
    id: "focus",
    title: "The verb selects a semantic focus",
    summary:
      "The four categories are Agent, Object/Goal/Patient, Referent, and Instrument/Cause/Motivation/Origin. The verb does not inflect for person, number, or gender, and not every verb has all four forms.",
    printedPages: "29–35",
    pdfPages: "39–45",
    modelRule:
      "Choose Agent, Object, Referent, or Instrument focus from the semantic role. Never manufacture a missing focus form: return insufficient when the required paradigm is unattested.",
  },
  {
    id: "focus-marking",
    title: "Noun-phrase marking follows focus",
    summary:
      "An expressed focused noun phrase takes a; an agent in a non-Agent-Focus clause takes nua; other nonfocused noun phrases generally take tua. Locatives can use i.",
    printedPages: "18, 31",
    pdfPages: "28, 41",
    modelRule:
      "Mark an expressed focused noun phrase with a, a non-Agent-Focus agent with nua, and other nonfocused noun phrases generally with tua; use locative i only when supported.",
  },
  {
    id: "questions",
    title: "Question words determine focus",
    summary:
      "Yes/no questions can differ from statements only by intonation. In a wh-question, the role being asked about determines focus; changing focus changes the question's meaning.",
    printedPages: "9, 33–34",
    pdfPages: "19, 43–44",
    modelRule:
      "For wh-questions, match focus to the questioned semantic role. Do not treat focus as optional emphasis. Preserve yes/no wording when only intonation distinguishes the question.",
  },
  {
    id: "aspect-and-commands",
    title: "Aspect and command forms are structured",
    summary:
      "Ferrell distinguishes neutral, continuative, projective/future, subjunctive, and perfective forms. AF -u is more peremptory, OF -i is the common/polite imperative, and RF -an is less common.",
    printedPages: "35–36",
    pdfPages: "45–46",
    modelRule:
      "Preserve neutral, continuative, projective, subjunctive, and perfective contrasts. Treat AF -u as brusquer than the common OF -i imperative; do not infer an imperative form without lexical support.",
  },
  {
    id: "negation",
    title: "Negatives are not interchangeable",
    summary:
      "ini negates doing, while neka negates existence. iru plus a subjunctive marks definite negative future. m-aya forms a negative command, with sa making it less peremptory.",
    printedPages: "12, 18, 36–37",
    pdfPages: "22, 28, 46–47",
    modelRule:
      "Distinguish ini for action negation from neka for nonexistence. Use iru plus subjunctive only for definite negative future and m-aya for negative commands when the construction is supported.",
  },
  {
    id: "intent",
    title: "Intent changes verb meaning",
    summary:
      "ki- and pa- tend toward intentional or directed action; ma- toward an affected, passive-like, or nonvolitional state; se- toward an unexpected event. pa- is not a universal causative.",
    printedPages: "37–40",
    pdfPages: "47–50",
    modelRule:
      "Preserve intent and volition contrasts. Never reduce pa- to a universal causative or use ki-, pa-, ma-, or se- as freely interchangeable derivations.",
  },
  {
    id: "reduplication",
    title: "Reduplication has bounded patterns",
    summary:
      "Common patterns repeat the initial consonant plus a, or repeat the stem without its final consonant. Verbs usually gain continuation or intensity; other words may gain diminutive, affectionate, or plural meaning.",
    printedPages: "28–29",
    pdfPages: "38–39",
    modelRule:
      "Interpret reduplication from attested context: usually continuation or intensity in verbs, and sometimes diminutive, affection, or dispersed plurality elsewhere. Do not generate it mechanically.",
  },
  {
    id: "word-order",
    title: "Predicate-first is the unmarked order",
    summary:
      "Postverbal noun phrases can move without changing meaning if their construction markers remain attached. A noun phrase can move before the predicate for emphasis.",
    printedPages: "37",
    pdfPages: "47",
    modelRule:
      "Prefer predicate-first order. Keep each construction marker with its noun phrase, and treat preposing as emphasis rather than a new grammatical relation.",
  },
  {
    id: "sound-changes",
    title: "Affixation can change sounds",
    summary:
      "Final w becomes v before a suffix, Agent Focus m becomes n after p, b, or v, and Object Focus -en has a vowel-conditioned -in form. Vowel contraction and optional schwa also occur.",
    printedPages: "10–11",
    pdfPages: "20–21",
    modelRule:
      "Respect the attested morphophonemic alternations w→v before suffixes and Agent Focus m→n after p, b, or v. Treat the source's vowel-conditioned OF -en/-in and contraction rules conservatively.",
  },
] as const;

export function buildFerrellPromptContext() {
  const rules = ferrellRuleCards
    .map((rule) => `- ${rule.modelRule} [Ferrell book pp. ${rule.printedPages}]`)
    .join("\n");

  return `Ferrell source scope and explicit rules:
- The source is Raleigh Ferrell, Paiwan Dictionary (1982), centered on Kulalau Paiwan. It is historical evidence, not a complete pan-Paiwan standard.
- The scanned PDF's OCR corrupts the phonemic characters ḍ and ł. No quarantined OCR spelling is included as model evidence.
${rules}`;
}
