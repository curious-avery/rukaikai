const DEFAULT_PROVIDER = "ollama";
const DEFAULT_BASE_URL = "http://127.0.0.1:11434/v1";
const DEFAULT_MODEL = "qwen3:4b-instruct";
const DEFAULT_LM_STUDIO_BASE_URL = "http://127.0.0.1:1234/v1";
const DEFAULT_LM_STUDIO_MODEL = "opengvlab_internvl3_5-38b";
const DEFAULT_TIMEOUT_MS = 180_000;

export type LocalLlmProvider = "ollama" | "lm-studio" | "openai-compatible";
export type RuKaiKaiMode = "demo" | "local";

const providerLabels: Record<LocalLlmProvider, string> = {
  ollama: "Ollama",
  "lm-studio": "LM Studio",
  "openai-compatible": "Local model",
};

export class LocalLlmTimeoutError extends Error {
  constructor() {
    super("The local model request timed out.");
    this.name = "LocalLlmTimeoutError";
  }
}

function isProvider(value: string): value is LocalLlmProvider {
  return new Set(["ollama", "lm-studio", "openai-compatible"]).has(value);
}

export function getLocalLlmConfig() {
  const legacyConfigured = [
    process.env.LM_STUDIO_BASE_URL,
    process.env.LM_STUDIO_MODEL,
    process.env.LM_STUDIO_TIMEOUT_MS,
    process.env.LM_STUDIO_API_KEY,
  ].some((value) => Boolean(value?.trim()));
  const requestedProvider = process.env.LOCAL_LLM_PROVIDER?.trim().toLowerCase();
  const provider: LocalLlmProvider =
    requestedProvider && isProvider(requestedProvider)
      ? requestedProvider
      : legacyConfigured
        ? "lm-studio"
        : DEFAULT_PROVIDER;
  const rawBaseUrl =
    process.env.LOCAL_LLM_BASE_URL?.trim() ||
    process.env.LM_STUDIO_BASE_URL?.trim() ||
    (provider === "lm-studio" ? DEFAULT_LM_STUDIO_BASE_URL : DEFAULT_BASE_URL);
  const model =
    process.env.LOCAL_LLM_MODEL?.trim() ||
    process.env.LM_STUDIO_MODEL?.trim() ||
    (provider === "lm-studio" ? DEFAULT_LM_STUDIO_MODEL : DEFAULT_MODEL);
  const apiKey =
    process.env.LOCAL_LLM_API_KEY?.trim() ||
    process.env.LM_STUDIO_API_KEY?.trim() ||
    null;
  const rawTimeout = Number(
    process.env.LOCAL_LLM_TIMEOUT_MS ?? process.env.LM_STUDIO_TIMEOUT_MS,
  );
  const timeoutMs = Number.isFinite(rawTimeout)
    ? Math.min(Math.max(rawTimeout, 1_000), 300_000)
    : DEFAULT_TIMEOUT_MS;

  const parsed = new URL(rawBaseUrl);
  if (!new Set(["http:", "https:"]).has(parsed.protocol)) {
    throw new Error("LOCAL_LLM_BASE_URL must use http or https.");
  }

  return {
    provider,
    providerLabel: providerLabels[provider],
    baseUrl: parsed.toString().replace(/\/$/, ""),
    model,
    apiKey,
    timeoutMs,
  };
}

export function getRuKaiKaiMode(requestUrl: string): RuKaiKaiMode {
  const requested = process.env.RUKAIKAI_MODE?.trim().toLowerCase();
  if (requested === "demo" || requested === "local") return requested;

  const hostname = new URL(requestUrl).hostname.toLowerCase();
  return new Set(["localhost", "127.0.0.1", "[::1]", "::1"]).has(hostname)
    ? "local"
    : "demo";
}

export async function fetchLocalLlm(
  pathname: string,
  init: RequestInit = {},
  timeoutOverride?: number,
) {
  const config = getLocalLlmConfig();
  const controller = new AbortController();
  const callerSignal = init.signal;
  const abortFromCaller = () => controller.abort(callerSignal?.reason);
  if (callerSignal?.aborted) {
    abortFromCaller();
  } else {
    callerSignal?.addEventListener("abort", abortFromCaller, { once: true });
  }
  let timedOut = false;
  const timeout = setTimeout(
    () => {
      timedOut = true;
      controller.abort();
    },
    timeoutOverride ?? config.timeoutMs,
  );

  const headers = new Headers(init.headers);
  if (config.apiKey && !headers.has("Authorization")) {
    headers.set("Authorization", `Bearer ${config.apiKey}`);
  }

  try {
    try {
      return await fetch(`${config.baseUrl}${pathname}`, {
        ...init,
        headers,
        signal: controller.signal,
      });
    } catch (error) {
      if (timedOut) throw new LocalLlmTimeoutError();
      throw error;
    }
  } finally {
    clearTimeout(timeout);
    callerSignal?.removeEventListener("abort", abortFromCaller);
  }
}

function withoutLatest(value: string) {
  return value.endsWith(":latest") ? value.slice(0, -":latest".length) : value;
}

export function modelIsAvailable(
  available: string[],
  configured: string,
  provider: LocalLlmProvider,
) {
  if (available.includes(configured)) return true;
  if (provider !== "ollama") return false;
  const wanted = withoutLatest(configured);
  return available.some((candidate) => withoutLatest(candidate) === wanted);
}
