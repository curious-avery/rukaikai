// Legacy LM Studio helper kept for callers that still import this module.
// New RuKaiKai code uses the provider-neutral local-llm.ts API.
const DEFAULT_BASE_URL = "http://127.0.0.1:1234/v1";
const DEFAULT_MODEL = "opengvlab_internvl3_5-38b";
const DEFAULT_TIMEOUT_MS = 180_000;

export class LmStudioTimeoutError extends Error {
  constructor() {
    super("LM Studio request timed out.");
    this.name = "LmStudioTimeoutError";
  }
}

export function getLmStudioConfig() {
  const rawBaseUrl =
    process.env.LM_STUDIO_BASE_URL?.trim() || DEFAULT_BASE_URL;
  const model = process.env.LM_STUDIO_MODEL?.trim() || DEFAULT_MODEL;
  const apiKey = process.env.LM_STUDIO_API_KEY?.trim() || null;
  const rawTimeout = Number(process.env.LM_STUDIO_TIMEOUT_MS);
  const timeoutMs = Number.isFinite(rawTimeout)
    ? Math.min(Math.max(rawTimeout, 1_000), 300_000)
    : DEFAULT_TIMEOUT_MS;

  const parsed = new URL(rawBaseUrl);
  if (!new Set(["http:", "https:"]).has(parsed.protocol)) {
    throw new Error("LM_STUDIO_BASE_URL must use http or https.");
  }

  return {
    baseUrl: parsed.toString().replace(/\/$/, ""),
    model,
    apiKey,
    timeoutMs,
  };
}

export async function fetchLmStudio(
  pathname: string,
  init: RequestInit = {},
  timeoutOverride?: number,
) {
  const config = getLmStudioConfig();
  const controller = new AbortController();
  const callerSignal = init.signal;
  const abortFromCaller = () => controller.abort(callerSignal?.reason);
  if (callerSignal?.aborted) {
    abortFromCaller();
  } else {
    callerSignal?.addEventListener("abort", abortFromCaller, { once: true });
  }
  let timedOut = false;
  const timeout = setTimeout(
    () => {
      timedOut = true;
      controller.abort();
    },
    timeoutOverride ?? config.timeoutMs,
  );

  const headers = new Headers(init.headers);
  if (config.apiKey && !headers.has("Authorization")) {
    headers.set("Authorization", `Bearer ${config.apiKey}`);
  }

  try {
    try {
      return await fetch(`${config.baseUrl}${pathname}`, {
        ...init,
        headers,
        signal: controller.signal,
      });
    } catch (error) {
      if (timedOut) throw new LmStudioTimeoutError();
      throw error;
    }
  } finally {
    clearTimeout(timeout);
    callerSignal?.removeEventListener("abort", abortFromCaller);
  }
}

export function modelIsAvailable(available: string[], configured: string) {
  return available.includes(configured);
}
