import {
  findDictionaryMatches,
  findFerrellReviewedMatches,
  normalizeDictionaryKey,
  retrieveDictionaryEvidence,
} from "@/lib/paiwan-dictionary";
import {
  findReviewedTranslation,
  type TranslationDirection,
} from "@/lib/paiwan-language-pack";

export type SourceDemoTranslationResult = {
  translation: string;
  alternatives: string[];
  status: "reference" | "ferrell" | "dictionary" | "local-required";
  note: string;
  warning: string | null;
  source:
    | "language-pack"
    | "ferrell-dictionary"
    | "dictionary"
    | "demo";
  model: null;
  evidenceCount: number;
  sourceDetails?: {
    author: "Raleigh Ferrell";
    year: 1982;
    dialect: string;
    entryPrintedPage: number;
    entryPdfPage: number;
    addendumPdfPage: number;
    license: "CC BY-SA 4.0";
  };
};

export function sourceIsProtected(text: string, protectedTerms: string) {
  const sourceKey = normalizeDictionaryKey(text);
  return protectedTerms
    .split(/[,;\n]/)
    .map((term) => normalizeDictionaryKey(term))
    .filter(Boolean)
    .includes(sourceKey);
}

/**
 * Performs the same source-only resolution as the hosted demo API without
 * making a network request. This is safe to use in a static browser export.
 */
export function translateWithSourceDemo(
  text: string,
  direction: TranslationDirection,
  protectedTerms = "",
): SourceDemoTranslationResult {
  const cleanText = text.trim();
  const reviewedTranslation = findReviewedTranslation(cleanText, direction);

  if (reviewedTranslation) {
    return {
      translation: reviewedTranslation,
      alternatives: [],
      status: "reference",
      note: "Published reference sentence from the RuKaiKai study.",
      warning: null,
      source: "language-pack",
      model: null,
      evidenceCount: 0,
    };
  }

  const protectedSource = sourceIsProtected(cleanText, protectedTerms);
  const ferrellMatches = protectedSource
    ? []
    : findFerrellReviewedMatches(cleanText, direction);

  if (ferrellMatches.length) {
    const primary = ferrellMatches[0];
    const alternatives = [
      ...new Set(ferrellMatches.slice(1).map((match) => match.translation)),
    ].filter((translation) => translation !== primary.translation);

    return {
      translation: primary.translation,
      alternatives,
      status: "ferrell",
      note: `Page-image-checked ${primary.dialect} entry from Ferrell, book p. ${primary.entryPrintedPage}; added on book p. 503.`,
      warning: primary.uncertain
        ? "Ferrell marks this addendum entry as uncertain (?). Review the source page before reuse."
        : null,
      source: "ferrell-dictionary",
      model: null,
      evidenceCount: ferrellMatches.length,
      sourceDetails: {
        author: "Raleigh Ferrell",
        year: 1982,
        dialect: primary.dialect,
        entryPrintedPage: primary.entryPrintedPage,
        entryPdfPage: primary.entryPdfPage,
        addendumPdfPage: primary.addendumPdfPage,
        license: "CC BY-SA 4.0",
      },
    };
  }

  const dictionaryMatches = protectedSource
    ? []
    : findDictionaryMatches(cleanText, direction);

  if (dictionaryMatches.length) {
    return {
      translation: dictionaryMatches[0],
      alternatives: dictionaryMatches.slice(1),
      status: "dictionary",
      note:
        dictionaryMatches.length === 1
          ? "Exact match in the supplied searchable word list."
          : `The supplied searchable word list has ${dictionaryMatches.length} exact ${direction === "paiwan-to-english" ? "meanings" : "Paiwan forms"}.`,
      warning: null,
      source: "dictionary",
      model: null,
      evidenceCount: dictionaryMatches.length,
    };
  }

  return {
    translation: "",
    alternatives: [],
    status: "local-required",
    note: "The online demo checks sourced matches only. Download RuKaiKai Local to draft new sentences with a model on your computer.",
    warning: null,
    source: "demo",
    model: null,
    evidenceCount: retrieveDictionaryEvidence(cleanText, direction).length,
  };
}
