// The lookup implementation is client-safe so static exports can perform exact
// source-backed matches without an API. Server routes keep importing this file
// to make the server boundary explicit.
export * from "@/lib/paiwan-dictionary";
