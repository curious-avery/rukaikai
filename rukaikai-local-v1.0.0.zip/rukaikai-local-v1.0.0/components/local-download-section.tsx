import {
  CheckCircle2,
  Download,
  ExternalLink,
  HardDriveDownload,
  Laptop,
  LockKeyhole,
  PackageCheck,
  TerminalSquare,
} from "lucide-react";

import { Badge } from "@/components/ui/badge";

/* eslint-disable @next/next/no-img-element */

const downloadAssetPath = "/downloads/rukaikai-local-v1.0.0.zip";

function withAssetBasePath(path: string, assetBasePath: string) {
  const base = assetBasePath.trim().replace(/\/+$/, "");
  if (!base || base === "/") return path;

  const normalizedBase =
    base.startsWith("/") || /^(?:https?:)?\/\//.test(base) ? base : `/${base}`;
  return `${normalizedBase}${path}`;
}

export function LocalDownloadSection({
  dictionaryEntryCount,
  grammarRuleCount,
  isLocal,
  assetBasePath = "",
}: {
  dictionaryEntryCount: number;
  grammarRuleCount: number;
  isLocal: boolean;
  assetBasePath?: string;
}) {
  const downloadPath = withAssetBasePath(downloadAssetPath, assetBasePath);
  const logoPath = withAssetBasePath(
    "/brand/rukaikai-logo.png",
    assetBasePath,
  );

  return (
    <section
      id="run-local"
      className="mt-8 scroll-mt-6"
      aria-labelledby="run-local-heading"
    >
      <div className="local-hero">
        <div className="max-w-3xl">
          <Badge className="border-white/20 bg-white/10 text-white hover:bg-white/10">
            {isLocal ? "RuKaiKai Local · running" : "RuKaiKai Local · v1.0.0"}
          </Badge>
          <p className="local-hero-eyebrow mt-5 text-sm font-black uppercase tracking-[0.14em]">
            Private local model edition
          </p>
          <h2
            id="run-local-heading"
            className="mt-2 text-3xl font-black tracking-[-0.045em] text-white sm:text-5xl"
          >
            Keep the model on your computer.
          </h2>
          <p className="mt-4 max-w-2xl text-base leading-7 text-white/75 sm:text-lg">
            {isLocal
              ? "This local edition combines the source-backed language pack with clearly labeled AI drafts for new sentences. Translation prompts stay on this device."
              : "Download the complete RuKaiKai starter kit to add clearly labeled AI drafts for new sentences. The recommended setup uses Ollama and a compact Qwen 4B model; after setup, translation prompts stay on your device."}
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            {isLocal ? (
              <span className="download-button">
                <CheckCircle2 className="size-5" aria-hidden="true" />
                Local edition is running
              </span>
            ) : (
              <a className="download-button" href={downloadPath} download>
                <Download className="size-5" aria-hidden="true" />
                Download the local starter kit
              </a>
            )}
            <a
              className="download-secondary"
              href="https://ollama.com/download"
              target="_blank"
              rel="noreferrer"
            >
              Get Ollama
              <ExternalLink className="size-4" aria-hidden="true" />
            </a>
          </div>
          <p className="mt-3 text-sm text-white/60">
            {isLocal ? (
              <>Your browser, RuKaiKai, and the model provider are all on this computer.</>
            ) : (
              <>
                About 500 KB · October 2026 · ZIP for macOS, Windows, and Linux ·
                the 2.5 GB model downloads separately on first setup · allow about
                5 GB of free storage ·{" "}
                <a
                  className="underline decoration-white/30 underline-offset-4"
                  href={downloadPath + ".sha256"}
                >
                  SHA-256 checksum
                </a>
              </>
            )}
          </p>
        </div>

        <div className="local-privacy-card">
          <div className="local-privacy-heading">
            <img
              src={logoPath}
              alt=""
              width={377}
              height={382}
              className="local-privacy-mark"
              aria-hidden="true"
            />
            <LockKeyhole className="local-lock-icon size-7" aria-hidden="true" />
          </div>
          <p className="mt-4 text-lg font-black text-white">Local by design</p>
          <p className="mt-2 text-sm leading-6 text-white/70">
            RuKaiKai talks to Ollama through your computer&apos;s loopback address.
            The launcher does not open the model server to your network or the
            internet.
          </p>
        </div>
      </div>

      {isLocal ? (
        <div className="mt-4 grid gap-4 lg:grid-cols-3">
          <article className="setup-step">
            <span>1</span>
            <CheckCircle2 className="brand-accent-icon size-6" aria-hidden="true" />
            <h3>The local app is installed</h3>
            <p>
              Keep this extracted folder together. It contains the app, launchers,
              language data, and source notices.
            </p>
          </article>
          <article className="setup-step">
            <span>2</span>
            <TerminalSquare className="brand-accent-icon size-6" aria-hidden="true" />
            <h3>Keep the model provider running</h3>
            <p>
              Ollama or your configured compatible provider must stay open while
              RuKaiKai creates a new model draft.
            </p>
          </article>
          <article className="setup-step">
            <span>3</span>
            <Laptop className="brand-accent-icon size-6" aria-hidden="true" />
            <h3>Use the launcher next time</h3>
            <p>
              Reopen the Mac, Windows, or Linux launcher from this folder whenever
              you want to start RuKaiKai again.
            </p>
          </article>
        </div>
      ) : (
        <div className="mt-4 grid gap-4 lg:grid-cols-3">
          <article className="setup-step">
            <span>1</span>
            <Laptop className="brand-accent-icon size-6" aria-hidden="true" />
            <h3>Install two prerequisites</h3>
            <p>
              Install Ollama and Node.js 22.13 or newer. Both offer installers for
              Mac, Windows, and Linux.
            </p>
            <div className="mt-4 flex flex-wrap gap-x-4 gap-y-2 text-sm font-bold">
              <a href="https://ollama.com/download" target="_blank" rel="noreferrer">
                Ollama <ExternalLink className="inline size-3" />
              </a>
              <a href="https://nodejs.org/en/download" target="_blank" rel="noreferrer">
                Node.js <ExternalLink className="inline size-3" />
              </a>
            </div>
          </article>

          <article className="setup-step">
            <span>2</span>
            <HardDriveDownload className="brand-accent-icon size-6" aria-hidden="true" />
            <h3>Download and unzip</h3>
            <p>
              Download the starter kit above, use Extract All, and move the
              RuKaiKai Local folder somewhere easy to find.
            </p>
          </article>

          <article className="setup-step">
            <span>3</span>
            <TerminalSquare className="brand-accent-icon size-6" aria-hidden="true" />
            <h3>Open the launcher</h3>
            <p>
              Double-click the Mac or Windows launcher, or run the Linux script.
              First launch installs app packages and downloads{" "}
              <code>qwen3:4b-instruct</code> through Ollama, then opens RuKaiKai at
              localhost. An 8 GB computer may be slow; 16 GB is more comfortable.
            </p>
          </article>
        </div>
      )}

      <div className="mt-4 grid gap-4 lg:grid-cols-[1.1fr_0.9fr]">
        <article className="info-card">
          <div className="flex items-center gap-3">
            <PackageCheck className="brand-accent-icon size-6" />
            <div>
              <p className="panel-label">Inside the download</p>
              <h3 className="mt-1 text-xl font-black">Everything RuKaiKai needs</h3>
            </div>
          </div>
          <ul className="download-checklist mt-5">
            <li>
              <CheckCircle2 /> RuKaiKai application source and launchers
            </li>
            <li>
              <CheckCircle2 /> {dictionaryEntryCount.toLocaleString()} normalized
              Paiwan–English word pairs
            </li>
            <li>
              <CheckCircle2 /> 10 published study-reference sentences
            </li>
            <li>
              <CheckCircle2 /> {grammarRuleCount} page-checked Ferrell grammar cards
            </li>
            <li>
              <CheckCircle2 /> Setup, troubleshooting, and source notices
            </li>
          </ul>
          <p className="mt-5 text-sm leading-6 text-muted-foreground">
            The Qwen model weights and original Ferrell PDF are not copied into the
            ZIP. Ollama downloads the model from its official registry, and the
            historical PDF remains linked to its ANU source.
          </p>
        </article>

        <article className="info-card">
          <p className="panel-label">Online demo vs. local edition</p>
          <div className="mode-comparison mt-4">
            <div>
              <strong>Online demo</strong>
              <span>Exact sourced matches</span>
              <span>No model installation</span>
              <span>Explore references and rules</span>
            </div>
            <div>
              <strong>Local edition</strong>
              <span>Exact matches plus AI drafts</span>
              <span>Private on-device inference</span>
              <span>Try new sentences</span>
            </div>
          </div>
          <details className="local-alternatives mt-5">
            <summary>Advanced model alternatives</summary>
            <p>
              The starter uses Qwen 3 4B Instruct. You may instead run Gemma 3 4B
              through Ollama or point the included configuration at LM Studio. A
              smaller model is convenient, but it does not make a draft verified.
            </p>
          </details>
        </article>
      </div>

      <div className="mt-4 rounded-2xl border border-amber-300 bg-amber-50 p-4 text-sm leading-6 text-amber-950 dark:border-amber-800 dark:bg-amber-950/50 dark:text-amber-100">
        <strong>Use with care.</strong> Every model result is an unverified draft.
        Ask a fluent Paiwan speaker or community reviewer before reuse, especially
        for medical, legal, emergency, ceremonial, or other sensitive language.
      </div>
    </section>
  );
}
